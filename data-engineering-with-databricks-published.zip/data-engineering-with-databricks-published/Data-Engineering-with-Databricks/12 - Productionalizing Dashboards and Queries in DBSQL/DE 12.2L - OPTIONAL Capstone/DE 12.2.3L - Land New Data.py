# Databricks notebook source
# MAGIC %run ../../Includes/Classroom-Setup-12.2.3L

# COMMAND ----------

DA.data_factory.load()

