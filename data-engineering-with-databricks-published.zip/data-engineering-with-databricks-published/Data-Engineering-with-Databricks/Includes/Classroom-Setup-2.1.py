# Databricks notebook source
# MAGIC %run ./_utility-methods $lesson="2.1"

# COMMAND ----------

DA.cleanup()
DA.init()
DA.conclude_setup()

