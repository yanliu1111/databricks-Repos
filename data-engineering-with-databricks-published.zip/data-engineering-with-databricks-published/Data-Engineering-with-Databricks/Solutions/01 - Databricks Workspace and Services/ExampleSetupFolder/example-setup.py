# Databricks notebook source
# ANSWER
my_name = "Donald Duck"

# COMMAND ----------

example_df = spark.range(16)

